/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nordens.paris;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 *
 * @author ida705e19
 */

// Main klassen i systemet.
public class Kontingentbetalingssystem extends Application {
    
    private static Stage guiStage;
    
    public static Stage getStage(){
        return guiStage;
    }

    // Sætter de nødvendige attributter, og er det første der sker, når programmet køres.
    @Override
    public void start(Stage primaryStage) {
        
        guiStage = primaryStage;
        Hold hold = new Hold();
        
        Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        
        BrugerprofilView brugerprofilView = new BrugerprofilView(hold);
        
        Scene scene = new Scene(brugerprofilView, bounds.getWidth(), bounds.getHeight());
        
        guiStage.setTitle("Nordens Paris");
        guiStage.setScene(scene);
        guiStage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
    
}