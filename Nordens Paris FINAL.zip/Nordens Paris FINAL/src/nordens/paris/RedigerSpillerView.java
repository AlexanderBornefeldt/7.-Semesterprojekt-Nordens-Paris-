/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nordens.paris;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Screen;

/**
 *
 * @author ida705e19
 */
public class RedigerSpillerView extends BorderPane {
    
    Hold hold;
    GridPane grid;
    Label ErrorTekst = new Label();
    
    // Kalder metode, der sletter den valgte spiller fra systemet
    private class SletSpiller implements EventHandler<ActionEvent> {
        @Override
        public void handle (ActionEvent event) {
            
            sletSpiller();            
            
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        KassererView kassererView = new KassererView(hold);
        Scene kView = new Scene(kassererView, bounds.getWidth(), bounds.getHeight()); 
        Kontingentbetalingssystem.getStage().setScene(kView);
        }
    }
    
    
    // Metode, der gemmer ændringer til den valgte spiller
    private class GemSpillerÆndringer implements EventHandler<ActionEvent> {
        
        @Override
        public void handle (ActionEvent event) {
            
            // KALD METODE DER GEMMER ÆNDRINGER TIL SPILLER
            if( nytholdbox.getValue() == hold.getList().get(0) ) {
                ikkeTilladt("Du kan ikke tilføje spillere til Alle Hold", "Tilføj spiller ikke tilladt");
                        } else {
            RedigerSpiller();
            
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        KassererView kassererView = new KassererView(hold);
        Scene kView = new Scene(kassererView, bounds.getWidth(), bounds.getHeight()); 
        Kontingentbetalingssystem.getStage().setScene(kView);
            }
        }
    }
    
    // Skifter scene  til KassererView
    private class AnnullerRedigerSpiller implements EventHandler<ActionEvent> {
        
        @Override
        public void handle (ActionEvent event) {
            
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        KassererView kassererView = new KassererView(hold);
        Scene kView = new Scene(kassererView, bounds.getWidth(), bounds.getHeight()); 
        Kontingentbetalingssystem.getStage().setScene(kView);
        }
    }
    
    // Metode, der finder den søgte spiller frem.
    private class søgHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            a = "Ingen spiller fundet";
            String x = spillerNavn.getText();
            for (int i = 0; i < hold.getList().size(); i++) {
                Hold hold1 = hold.getList().get(i);
                for (int j = 0; j < hold.getSpillerListe(hold1).size(); j++) {
                    String spiller = hold.getSpillerListe(hold1).get(j).getNavn();
                    if (x.equals(spiller)) {
                        a = x;
                    } else {
                    }
                }
            }
            redigerSpillerNavn.setText(a);
        }
    }

    TextField redigerSpillerNavn;
    TextField kontingentpris;
    //Kenny 27/11
    TextField spillerNavn;
    ComboBox<Hold> nytholdbox;
    String a = "Ingen spiller fundet";
    
    // Konstruktør for RedigerSpillerView
    public RedigerSpillerView(Hold hld) {
        
        this.hold = hld;        
        this.setPadding(new Insets(25, 25, 25, 25));
    
        
    // Elementer i center af BorderPane.  
        grid = new GridPane();
            
             //Kenny 27/11
            Label SpillerNavn = new Label("Spillernavn:");
              grid.setHgap(10);
              grid.setVgap(50);
            spillerNavn = new TextField("Indtast navn...");
              spillerNavn.setPrefSize(200, 30); 
              
              
              Button søg = new Button("Søg");
              søg.setOnAction(new søgHandler());
            
            Label redigerNavn = new Label("Rediger navn:");
                grid.setHgap(10);
                grid.setVgap(50);
            redigerSpillerNavn = new TextField( "Spillerens navn vises..." );
                redigerSpillerNavn.setPrefSize(200, 30);
                
                
            Label nytHoldValg = new Label("Vælg nyt hold:");
            
            nytholdbox = new ComboBox<>(FXCollections.observableArrayList(hold.getList()));
             nytholdbox.getSelectionModel().selectFirst();
             nytholdbox.setPrefSize(250, 30); 

        grid.add(SpillerNavn, 0, 0);
        grid.add(spillerNavn, 1, 0);
        grid.add(søg, 2, 0);
        grid.add(redigerNavn, 0, 1);
        grid.add(redigerSpillerNavn, 1, 1, 2, 1);
        grid.add(nytHoldValg, 0, 2);
        grid.add(nytholdbox, 1, 2, 2, 1);
        
        grid.setAlignment(Pos.CENTER);
        
    this.setCenter(grid);
    // Færdig med center
        
    // Elementer i bunden af BorderPane.

        HBox sletKnap = new HBox();
        Button slet = new Button("Slet");
            slet.setPrefSize(200, 30);
            sletKnap.getChildren().add(slet);
            sletKnap.setPadding(new Insets(25, 25, 25, 25));
            sletKnap.setAlignment(Pos.BOTTOM_LEFT);
                slet.setOnAction(new SletSpiller());
        
        HBox knapper = new HBox();
            Button annuller = new Button("Annuller");
                annuller.setPrefSize(200, 30);
                    annuller.setOnAction(new AnnullerRedigerSpiller());
            Button gem = new Button("Gem");
                gem.setPrefSize(200, 30);
                    gem.setOnAction(new GemSpillerÆndringer());
                    
                    knapper.getChildren().addAll(annuller, gem);
                    knapper.setSpacing(25);
                    knapper.setPadding(new Insets(25, 25, 25, 25));
                    knapper.setAlignment(Pos.BOTTOM_LEFT);
                
        GridPane logoOgKnap = new GridPane();
            logoOgKnap.add(sletKnap, 0, 0);
            logoOgKnap.add(knapper, 1, 0);
            
                    ColumnConstraints sletKol = new ColumnConstraints();
                    sletKol.setPercentWidth(20);
                    logoOgKnap.getColumnConstraints().addAll(sletKol);
            
                    ColumnConstraints knapperKol = new ColumnConstraints();
                    knapperKol.setPercentWidth(30);
                    logoOgKnap.getColumnConstraints().addAll(knapperKol);
                    
                    ColumnConstraints logoKol = new ColumnConstraints();
                    logoKol.setPercentWidth(50);
                    logoOgKnap.getColumnConstraints().addAll(logoKol);

    this.setBottom(logoOgKnap);
    // Færdig med bunden
    }
    
    // Metode, der redigerer værdierne for en spiller
    private void RedigerSpiller() {
        
        Spiller spillerobj;
        Hold nytHold = nytholdbox.getSelectionModel().getSelectedItem();
        String spiller = spillerNavn.getText();
        
        // Hvis der bliver fundet et navn i SøgHandler
        if(!a.equals("Ingen spiller fundet")){
            
            // Gå igennem alle hold
            for (int i = 1; i < hold.getList().size(); i++) {
                Hold holdIArray = hold.getList().get(i);
                
                // Få Spillerliste fra det igangværende HoldArray
                for (int j = 0; j < hold.getSpillerListe(holdIArray).size(); j++) {
                    String splr = hold.getSpillerListe(holdIArray).get(j).getNavn();
                    
                    if( spiller.equals(splr) ) {
                        spillerobj = hold.getSpillerListe(holdIArray).get(j);
                        spillerobj.setHold( nytHold );
                        spillerobj.setNavn(redigerSpillerNavn.getText());
                            hold.getSpillerListe(nytHold).add(spillerobj);
                            hold.getSpillerListe(holdIArray).remove(spillerobj);
                    }
                }  
            }  
        } else {
            System.out.println("");
        }              
    }
    // Metode, der sletter en spiller
    public void sletSpiller() {
        
        Spiller spillerobj;
        String spiller = spillerNavn.getText();
        
        // Hvis der bliver fundet et navn i SøgHandler
        if(!a.equals("Ingen spiller fundet")){
            
            // Gå igennem alle hold
            for (int i = 1; i < hold.getList().size(); i++) {
                Hold holdIArray = hold.getList().get(i);
                
                // Få Spillerliste fra det igangværende HoldArray
                for (int j = 0; j < hold.getSpillerListe(holdIArray).size(); j++) {
                    String splr = hold.getSpillerListe(holdIArray).get(j).getNavn();
                        if( spiller.equals(splr) ) {
                            spillerobj = hold.getSpillerListe(holdIArray).get(j);
                            hold.getSpillerListe(holdIArray).remove(spillerobj);
                    }
                }  
            }  
        } else {
            System.out.println("");
        }  
    }
    // Metode, informerer brugeren når en handling ikke er tilladt i systemet
    public void ikkeTilladt(String error, String header) {
        
        Alert errorAlert = new Alert(Alert.AlertType.ERROR, error);
            errorAlert.setTitle("Fejlmeddelelse");
            errorAlert.setHeaderText(header);
            errorAlert.showAndWait();
    }

}



        
