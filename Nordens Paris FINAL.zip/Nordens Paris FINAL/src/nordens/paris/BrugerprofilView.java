/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nordens.paris;


import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Screen;


/**
 *
 * @author ida705e19
 */
public class BrugerprofilView extends BorderPane {
    
    Hold hold;
    
    // Skifter scene til KassererView
    public class GåTilKassererView implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
            KassererView kassererview = new KassererView(hold);
            Scene tsView = new Scene(kassererview, bounds.getWidth(), bounds.getHeight());
            Kontingentbetalingssystem.getStage().setScene(tsView); 
        }
    }
    
    // Skifter scene til TrænerView
    public class GåTilTrænerView implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
            TrænerView trænerview = new TrænerView(hold);
            Scene tsView = new Scene(trænerview, bounds.getWidth(), bounds.getHeight());
            Kontingentbetalingssystem.getStage().setScene(tsView);
        }
    }
    
    // Konstruktør for BrugerprofilView
    public BrugerprofilView( Hold hld ) {
        
        this.hold = hld;
        this.setPadding(new Insets(100, 25, 25, 25));
        
        Label intro = new Label("Velkommen til kontingentsystemet for");
            intro.setFont(Font.font("Verdana", FontWeight.NORMAL, 24));
            intro.setPadding(new Insets(0, 0, 25, 0));
            
        Label np = new Label("Nordens Paris FC");
            np.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 40));
            
        // Tilføjer ovenstående Labels til GridPanen og sætter deres position
        GridPane txt = new GridPane();
            txt.add(intro, 0, 0);
            txt.add(np, 0, 1);
            txt.setAlignment(Pos.CENTER);
            txt.setHalignment(intro, HPos.CENTER);
            txt.setHalignment(np, HPos.CENTER);
            
            
        Label vælg = new Label("For at tilgå systemet, vælg om du er:");
            vælg.setFont(Font.font("Verdana", FontWeight.NORMAL, 20));
        Label eller = new Label("Eller:");
            eller.setFont(Font.font("Verdana", FontWeight.NORMAL, 20));
                
        VBox bruger = new VBox();
            Button kasserer = new Button("Kasserer");
                kasserer.setPrefSize(300, 50);
                kasserer.setFont(Font.font("Verdana", FontWeight.BOLD, 20));            
                    kasserer.setOnAction(new GåTilKassererView());
            Button træner = new Button("Træner");
                træner.setPrefSize(300, 50);
                træner.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
                    træner.setOnAction(new GåTilTrænerView());

        // Tilføjer ovenstående Labels og Buttons til en VBox
        bruger.getChildren().addAll(vælg, kasserer, eller, træner);
            bruger.setSpacing(30);
            bruger.setAlignment(Pos.CENTER);
        
        // Tilføjer logo
        Image logo = new Image("https://migogaalborg.dk/wp-content/uploads/2016/09/NordensParis-logo.jpg", 200, 200, false, false);
            ImageView visLogo = new ImageView(logo);
                StackPane pane = new StackPane(visLogo);
                    pane.setAlignment(Pos.BOTTOM_CENTER);

        // Tilføjer ovenstående elementer til deres position i GridPanen
        this.setTop(txt);
        this.setCenter(bruger);
        this.setBottom(pane);
    }
}
