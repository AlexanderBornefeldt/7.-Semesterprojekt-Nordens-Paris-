/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nordens.paris;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author ida705e19
 */
public class Hold {
    
    // Hold attributter:
    private String holdnavn;
        // ArrayList, hvor der tilføjes spillere. Hvert hold har en Spillerliste tilknyttet
    private ArrayList<Spiller> spillerliste; 
    private int basisKontingentpris;
    private int rykkergebyr;
    private int samletPris;
        // ArrayList, hvor der tilføjes hold. Ved at kombinere en ArrayList af Hold med en ArrayList af Spillere, kan vi gennemgå samtlige spillere i hele klubben.
            // Dette vil blive benyttet flere steder i koden.
    private ArrayList<Hold> holdliste;
    // JavaFX attributer:
    private LocalDate betalingsfrist;
    private boolean startBP;
    
    // Første konstruktør for Hold klassen
    public Hold(String holdnavn, int kontingentpris) {
        this.holdnavn = holdnavn;
        this.basisKontingentpris = kontingentpris;
        this.rykkergebyr = 0;
        this.spillerliste = new ArrayList<>();                
    }
    
    // Anden konstruktør for Hold klassen
        // Vi har to konstruktører i Hold klassen, da vi skal have mulighed for at lave et statisk hold, som skal indeholde information om de andre hold i klubben
    public Hold() {
        holdliste = new ArrayList<>();
        holdliste.add(new Hold("Alle Hold", 0) );
    }
    
    // Metoder
    public String getHoldnavn() {
        return holdnavn;
    }

    public void setHoldnavn(String holdnavn) {
        this.holdnavn = holdnavn;
    }

    public int getBasisKontingentpris() {
        return basisKontingentpris;
    }

    public int getRykkergebyr() {
        return rykkergebyr;
    }
    public void setRykkergebyr( int gebyr ) {
        this.rykkergebyr = gebyr;
    }
    
    public int getSamletPris() {
        return basisKontingentpris + rykkergebyr;
    }
    
    public void setBasisKontingentpris(int pris) {
        basisKontingentpris = pris;
    }
    
    // Tilføjer 50 kr. til rykkergebyret. Denne metode bliver kaldt hver gang kassereren trykker "Udsend Rykker".
    public void tilføjRykker() {
        rykkergebyr = rykkergebyr + 50;
    }
    // Returnerer listen med samtlige hold i klubben
    public ArrayList<Hold> getList() {
        return holdliste;
    }
    // Overrider en toString metode, så vi kan få fat i holdnavnets værdi
    @Override
    public String toString () {
        return this.holdnavn;
    }
    // Tilføjer en spiller til en spillerliste for et hold
    public void tilføjSpiller(Spiller spiller){
        spillerliste.add(spiller);
    }
    // Returnerer listen med spillere for et hold
    public ArrayList<Spiller> getSpillerListe(Hold hold){
        return hold.spillerliste;
    }
    
    public void setBetalingsfrist( LocalDate frist ) {
        this.betalingsfrist = frist;
    }
    public LocalDate getBetalingsfrist() {
        return this.betalingsfrist;
    }
    
    public void startBP( Boolean bool ) {
        this.startBP = bool;
    }
    public boolean getStartBP() {
        return startBP;
    }
    
}
