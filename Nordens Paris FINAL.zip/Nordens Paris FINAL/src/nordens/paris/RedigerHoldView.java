/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nordens.paris;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Screen;

/**
 *
 * @author ida705e19
 */


public class RedigerHoldView extends BorderPane {
    
    Hold hold;
    ComboBox<Hold> holdbox;
    GridPane grid;
    Label ErrorTekst = new Label();
    
    // Kalder metode, der sletter det valgte hold fra systemet. Læg mærke til, at det kun er tilladt såfremt der ikke er spillere på holdet.
    private class SletHold implements EventHandler<ActionEvent> {
        @Override
        public void handle (ActionEvent event) {
            
            Hold k = holdbox.getValue();
            
            for( int i = 0; i < hold.getList().size(); i++ ) {
                
                if( k == hold.getList().get(0) ) {
                    ikkeTilladt("Du kan ikke slette Alle Hold", "Redigering ikke tilladt");
                    break;
                } else if( !hold.getList().get(i).getSpillerListe(k).isEmpty() ) {
                    ikkeTilladt("Fjern alle spillere fra holdet før det kan slettes", "Sletning ikke tilladt");
                    break;
                } else if( hold.getList().get(i).getSpillerListe(k).isEmpty() ) {
                    hold.getList().remove(k);   
                    
        Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        KassererView kassererView = new KassererView(hold);
        Scene kView = new Scene(kassererView, bounds.getWidth(), bounds.getHeight()); 
        Kontingentbetalingssystem.getStage().setScene(kView);
        break;
               } 
            }
       }
    }
    
    // Metode, der gemmer ændringer til det valgte hold
    private class GemHoldÆndringer implements EventHandler<ActionEvent> {
        
        @Override
        public void handle (ActionEvent event) {

            if( holdbox.getValue() == hold.getList().get(0) ) {
                ikkeTilladt("Du kan ikke redigere Alle Hold", "Redigering ikke tilladt");
            } else {
            RedigerHold();
            
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        KassererView kassererView = new KassererView(hold);
        Scene kView = new Scene(kassererView, bounds.getWidth(), bounds.getHeight()); 
        Kontingentbetalingssystem.getStage().setScene(kView);
            }
        }
    }
    
    // Skifter scene til KassererView
    private class AnnullerRedigerHold implements EventHandler<ActionEvent> {
        
        @Override
        public void handle (ActionEvent event) {
            
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        KassererView kassererView = new KassererView(hold);
        Scene kView = new Scene(kassererView, bounds.getWidth(), bounds.getHeight()); 
        Kontingentbetalingssystem.getStage().setScene(kView);
        }
    }
    
    // Henter værdierne tilknyttet det valgte hold i ComboBoxen
    private class VisComboBoxElement implements EventHandler<ActionEvent> {
        
        @Override
        public void handle (ActionEvent event) {
            
            Hold k = holdbox.getValue();
            for( int i = 0; i < hold.getList().size(); i++ ) {
                holdnavn.setText( k.getHoldnavn() );
                kontingentpris.setText( Integer.toString( k.getBasisKontingentpris() ));
                        if( holdbox.getValue() == hold.getList().get(0) ) {
                            holdnavn.setText("Holdets navn vises her...");
                            kontingentpris.setText("Holdets pris vises her...");
                    }
            }
        }
    }
    
    TextField holdnavn;
    TextField kontingentpris;
    
    // Konstruktør for RedigerHoldView
    public RedigerHoldView(Hold hld) {
        
        this.hold = hld;
        this.setPadding(new Insets(25, 25, 25, 25));
        
    // Elementer i center af BorderPane.   
        grid = new GridPane();
            
        Label holdValg = new Label("Vælg hold:");
        
            holdbox = new ComboBox<>(FXCollections.observableArrayList( hold.getList() ) );
                holdbox.getSelectionModel().selectFirst();
                holdbox.setPrefSize(200, 30);
                    holdbox.setOnAction(new VisComboBoxElement());
             
            Label holdNavn = new Label("Holdnavn:");
                grid.setHgap(10);
                grid.setVgap(50);
            holdnavn = new TextField( "Holdets navn vises her..." );
                holdnavn.setPrefSize(200, 30);
            Label pris = new Label("Kontingentpris:");
            
            kontingentpris = new TextField("Holdets pris vises her...");
                kontingentpris.setPrefSize(200, 30);

        grid.add(holdValg, 0, 0);
        grid.add(holdbox, 1, 0);
        grid.add(holdNavn, 0, 1);
        grid.add(holdnavn, 1, 1);
        grid.add(pris, 0, 2);
        grid.add(kontingentpris, 1, 2);
        
        grid.setAlignment(Pos.CENTER);
        
    this.setCenter(grid);
    // Færdig med center
        
    // Elementer i bunden af BorderPane.

        HBox sletKnap = new HBox();
        Button slet = new Button("Slet");
            slet.setPrefSize(200, 30);
            sletKnap.getChildren().add(slet);
            sletKnap.setPadding(new Insets(25, 25, 25, 25));
            sletKnap.setAlignment(Pos.BOTTOM_LEFT);
                slet.setOnAction(new SletHold());
        
        HBox knapper = new HBox();
            Button annuller = new Button("Annuller");
                annuller.setPrefSize(200, 30);
                    annuller.setOnAction(new AnnullerRedigerHold());
            Button gem = new Button("Gem");
                gem.setPrefSize(200, 30);
                    gem.setOnAction(new GemHoldÆndringer());
                    
                    knapper.getChildren().addAll(annuller, gem);
                    knapper.setSpacing(25);
                    knapper.setPadding(new Insets(25, 25, 25, 25));
                    knapper.setAlignment(Pos.BOTTOM_LEFT);
                
        GridPane logoOgKnap = new GridPane();
            logoOgKnap.add(sletKnap, 0, 0);
            logoOgKnap.add(knapper, 1, 0);
            
                    ColumnConstraints sletKol = new ColumnConstraints();
                    sletKol.setPercentWidth(20);
                    logoOgKnap.getColumnConstraints().addAll(sletKol);
            
                    ColumnConstraints knapperKol = new ColumnConstraints();
                    knapperKol.setPercentWidth(30);
                    logoOgKnap.getColumnConstraints().addAll(knapperKol);
                    
                    ColumnConstraints logoKol = new ColumnConstraints();
                    logoKol.setPercentWidth(50);
                    logoOgKnap.getColumnConstraints().addAll(logoKol);

    this.setBottom(logoOgKnap);
    // Færdig med bunden
    }

    // Metode, der henter værdierne for det valgte hold
    public void RedigerHold() {
        
        Hold k = holdbox.getSelectionModel().getSelectedItem();
            for( int i = 0; i < hold.getList().size(); i++ ) {
                k.setHoldnavn( holdnavn.getText() );
                k.setBasisKontingentpris( Integer.parseInt(kontingentpris.getText() ) );
            }
    }
    // Metode, informerer brugeren når en handling ikke er tilladt i systemet
    public void ikkeTilladt(String error, String header) {
        
        Alert errorAlert = new Alert(Alert.AlertType.ERROR, error);
            errorAlert.setTitle("Fejlmeddelelse");
            errorAlert.setHeaderText(header);
            errorAlert.showAndWait();
    }
    
}
