/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nordens.paris;


import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Screen;


/**
 *
 * @author ida705e19
 */
public class TilføjSpillerView extends BorderPane {

    Hold hold;
    TextField spillerNavn;
    ComboBox<Hold> holdbox;
    GridPane grid;
    Label ErrorTekst = new Label();
    
    // Kalder metode, der tilføjer en spiller i systemet
    private class TilføjSpillerHandler implements EventHandler<ActionEvent> {
        
        @Override
        public void handle (ActionEvent event) {
            
            // KALD METODER DER SKABER OG TILFØJER ET SPILLER OBJEKT TIL ET HOLD
            if( holdbox.getValue() == hold.getList().get(0) ) {
                ikkeTilladt("Du kan ikke tilføje spillere til Alle Hold", "Tilføj spiller ikke tilladt");
                } else {
            TilføjSpiller();
            
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        KassererView kassererView = new KassererView(hold);
        Scene kView = new Scene(kassererView, bounds.getWidth(), bounds.getHeight()); 
        Kontingentbetalingssystem.getStage().setScene(kView);
                }
        }
    }
        
    // Skifter scene til KassererView
    private class AnnullerSpiller implements EventHandler<ActionEvent> {
        
        @Override
        public void handle (ActionEvent event) {
            
        Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        KassererView kassererView = new KassererView(hold);
        Scene kView = new Scene(kassererView, bounds.getWidth(), bounds.getHeight()); 
        Kontingentbetalingssystem.getStage().setScene(kView);
        }
    }
    
    
    // Konstruktør for TilføjSpillerView
    public TilføjSpillerView(Hold hld) {
        this.hold = hld;
        this.setPadding(new Insets(25, 25, 25, 25));
     
    // Elementer i center af BorderPane.
        grid = new GridPane();
            Label navn = new Label("Navn:");
                grid.setHgap(10);
                grid.setVgap(50);
            spillerNavn = new TextField("Indtast navn...");
                spillerNavn.setPrefSize(200, 30);
            Label holdValg = new Label("Vælg hold:");
            
            holdbox = new ComboBox<>(FXCollections.observableArrayList(hold.getList()));
             holdbox.getSelectionModel().selectFirst();
             holdbox.setPrefSize(200, 30);            

        grid.add(navn, 0, 0);
        grid.add(spillerNavn, 1, 0);
        grid.add(holdValg, 0, 1);
        grid.add(holdbox, 1, 1);
        
        grid.setAlignment(Pos.CENTER);
        
    this.setCenter(grid);
    // Færdig med center

    // Elementer i bunden af BorderPane.
        HBox knapper = new HBox();
            Button annuller = new Button("Annuller");
                annuller.setPrefSize(200, 30);
                    annuller.setOnAction(new AnnullerSpiller());
            Button gem = new Button("Gem");
                gem.setPrefSize(200, 30);
                    gem.setOnAction(new TilføjSpillerHandler());
                    
                    knapper.getChildren().addAll(annuller, gem);
                    knapper.setSpacing(25);
                    knapper.setPadding(new Insets(125, 25, 25, 25));
                    knapper.setAlignment(Pos.CENTER_LEFT);
                
        GridPane logoOgKnap = new GridPane();
            logoOgKnap.add(knapper, 0, 0);
            
                    ColumnConstraints knapperKol = new ColumnConstraints();
                    knapperKol.setPercentWidth(70);
                    logoOgKnap.getColumnConstraints().addAll(knapperKol);
                    
                    ColumnConstraints logoKol = new ColumnConstraints();
                    logoKol.setPercentWidth(30);
                    logoOgKnap.getColumnConstraints().addAll(logoKol);

    this.setBottom(logoOgKnap);
    // Færdig med bunden
    }
    // Metode, der tilføjer en spiller
    public void TilføjSpiller(){
        
        String SpillerNavn = spillerNavn.getText();       
        Hold hld = holdbox.getSelectionModel().getSelectedItem(); 
        
        if( hld == hold.getList().get(0) ) {
            Label tilføjTilAndetHold = new Label("*Tilføj spiller til et hold");
                tilføjTilAndetHold.setTextFill(Color.RED);
                   grid.add(tilføjTilAndetHold, 2, 0);
        } else {
            Spiller spiller = new Spiller (SpillerNavn, hld);
                hld.tilføjSpiller(spiller); 
                }
    }
    // Metode, informerer brugeren når en handling ikke er tilladt i systemet
    public void ikkeTilladt(String error, String header) {
        
        Alert errorAlert = new Alert(Alert.AlertType.ERROR, error);
            errorAlert.setTitle("Fejlmeddelelse");
            errorAlert.setHeaderText(header);
            errorAlert.showAndWait();
    }

}
