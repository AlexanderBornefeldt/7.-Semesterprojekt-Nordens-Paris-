/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nordens.paris;

/**
 *
 * @author ida705e19
 */
public class Spiller {

    // Spiller attributter:
    private String navn;
    private boolean betalt;
    private Hold hold;
    private int betaltPris;
    private String kommentar;
    // JavaFX attribut:
    private boolean udsendRykkerKlikket;

    // Konstruktør for Spiller klassen
    public Spiller(String navn, Hold hold) {
        this.navn = navn;
        this.hold = hold;
        this.betalt = false;
        this.betaltPris = 0;
    }

    // Metoder
    public String getNavn() {
        return navn;
    }
    public void setNavn(String spillerNavn) {
        navn = spillerNavn;
    }

    public boolean getBetalt() {
        return betalt;
    }
    public void setBetalt(boolean erBetalt) {
        betalt = erBetalt;
    }
    
    public Hold getHold() {
        return hold;
    }
    public void setHold(Hold holdNavn) {
        hold = holdNavn;
    }
    
    public int getBetaltPris() {
        return betaltPris;
    }
    public void setBetaltPris( int beløb ) {
        this.betaltPris = beløb;
    }
    
    public String getKommentar() {
        return kommentar;
    }
    public void setKommentar(String str) {
        this.kommentar = str;
    }

    // JavaFX metoder
        // Så systemet ved om kassereren har klikket "Udsend Rykker".
    public void UdsendRykkerKlikket(Boolean bool) {
        this.udsendRykkerKlikket = bool;
    }
    public boolean getUdsendRykkerKlikket() {
        return udsendRykkerKlikket;
    }
    // Nulstiller betalinger
    public void nulstilBetaling (boolean betalt) {
        this.betalt = false;
        
    }

}
