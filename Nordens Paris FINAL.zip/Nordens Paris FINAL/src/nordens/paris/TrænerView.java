/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nordens.paris;

import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Screen;

/**
 *
 * @author ida705e19
 */
public class TrænerView extends BorderPane {

    Hold hold;
    ComboBox<Hold> holdbox;
    GridPane spillerList;
    CheckBox check;
    Boolean checkpressed;
    StackPane rowPane;
    Text betalingsfrist = new Text();
    Text kontingentPris1;

    // EVENTHANDLERS

    private class VælgHoldHandler implements EventHandler<ActionEvent> {
 
        @Override
        public void handle(ActionEvent event) {
      // Nulstiller alle elementer på GridPanen
            nulstilGridPane();
       
        // Sætter første række i GridPanen
       int m = 1;            
            if( holdbox.getValue() == hold.getList().get(0) ) {
                gridPaneAlleSpillere( m, holdbox.getValue() );
            } else {
                gridPaneHoldSpillere( m, holdbox.getValue() );
            }
        }
    }


    private class Tekstfelt implements EventHandler<KeyEvent> {
        
        TextField txtf;
        Spiller markeretSpiller;
        
        public Tekstfelt(Spiller g, TextField t) {
            this.markeretSpiller = g;
            this.txtf = t;
        }
        @Override
        public void handle(KeyEvent event) {  
            markeretSpiller.setKommentar( txtf.getText() );   
        }
    }
    
    private class TilBrugerProfilView implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
            BrugerprofilView brugerprofilview = new BrugerprofilView(hold);
            Scene thView = new Scene(brugerprofilview, bounds.getWidth(), bounds.getHeight());
            Kontingentbetalingssystem.getStage().setScene(thView);
        }    
    }
    
    // CONSTRUCTOR
    public TrænerView(Hold hld) {

        this.hold = hld;
        this.setPadding(new Insets(25, 25, 25, 25));

        //margins around the whole grid when using .setPadding(new Insets(...) )
        //(top/right/bottom/left)
        // LEFT AF BORDERPANE
        VBox venstre = new VBox();

        VBox kontingentPriser = new VBox();
        for (int a = 1; a < hold.getList().size(); a++) {
            kontingentPris1 = new Text(hold.getList().get(a).getHoldnavn()
                    + " : " + hold.getList().get(a).getSamletPris() + " kr.");
            kontingentPris1.setFont(Font.font("Verdana", 16));
            kontingentPriser.getChildren().add(kontingentPris1);
        }

        holdbox = new ComboBox<>(FXCollections.observableArrayList(hold.getList()));
        holdbox.getSelectionModel().selectFirst();
        holdbox.setPrefSize(200, 30);
            holdbox.setOnAction(new VælgHoldHandler());

        if( hold.getStartBP() ) {
            betalingsfrist.setText( "Frist for betaling: "  + hold.getBetalingsfrist().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG)) );
            betalingsfrist.setFill(Color.BLACK);
        } else if( !hold.getStartBP() ) {
            betalingsfrist.setText( "Betalingsperiode ikke aktiv");
            betalingsfrist.setFill(Color.RED);
        }

        venstre.getChildren().addAll( holdbox, betalingsfrist, kontingentPriser );
        venstre.setSpacing(25);
        venstre.setPadding(new Insets(50, 25, 0, 0));

        this.setLeft(venstre);
        // SLUT PÅ LEFT

        // TOP AF BORDERPANE
        GridPane top = new GridPane();
        top.setHgap(200);
        top.setVgap(0);
        top.setAlignment(Pos.CENTER_RIGHT);
        
        Button tilBrugerProfil = new Button("Skift Brugerprofil");
            tilBrugerProfil.setPrefSize(200, 30);
            tilBrugerProfil.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
                tilBrugerProfil.setOnAction(new TilBrugerProfilView());
                
        HBox tilBPtop = new HBox();
            tilBPtop.getChildren().add(tilBrugerProfil);
            tilBPtop.setPadding(new Insets(0, 0, 25, 0));
            
        top.add(tilBPtop, 1, 0);
        this.setTop(top);

        // CENTER AF BORDERPANE
        spillerList = new GridPane();
        spillerList.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
        spillerList.setPadding(new Insets(25, 0, 0, 25));
        spillerList.setStyle("-fx-border-width: 1; -fx-border-color: black;");

        Text navn = new Text("Navn");
        navn.setFont(Font.font("Verdana", FontWeight.BOLD, 16));
        Text holdNavn = new Text("Hold");
        holdNavn.setFont(Font.font("Verdana", FontWeight.BOLD, 16));
        Text betaltBeløb = new Text("Beløb");
        betaltBeløb.setFont(Font.font("Verdana", FontWeight.BOLD, 16));
        Text betaltEllerEj = new Text("Betalt");
        betaltEllerEj.setFont(Font.font("Verdana", FontWeight.BOLD, 16));
        Text kommentar = new Text("Kommentar");
        kommentar.setFont(Font.font("Verdana", FontWeight.BOLD, 16));

        ColumnConstraints spillerNavnKol = new ColumnConstraints();
        spillerNavnKol.setPercentWidth(30);
        spillerList.getColumnConstraints().addAll(spillerNavnKol);

        ColumnConstraints holdNavnKol = new ColumnConstraints();
        holdNavnKol.setPercentWidth(15);
        spillerList.getColumnConstraints().addAll(holdNavnKol);

        ColumnConstraints betaltBeløbKol = new ColumnConstraints();
        betaltBeløbKol.setPercentWidth(10);
        spillerList.getColumnConstraints().addAll(betaltBeløbKol, betaltBeløbKol);

        ColumnConstraints kommentarKol = new ColumnConstraints();
        kommentarKol.setPercentWidth(44);
        spillerList.getColumnConstraints().addAll(kommentarKol);

        ColumnConstraints scrollbarKol = new ColumnConstraints();
        scrollbarKol.setPercentWidth(1);
        spillerList.getColumnConstraints().add(scrollbarKol);

        spillerList.add(navn, 0, 0);
        spillerList.add(holdNavn, 1, 0);
        spillerList.add(betaltBeløb, 2, 0);
        spillerList.add(betaltEllerEj, 3, 0);
        spillerList.add(kommentar, 4, 0);

        gridPaneAlleSpillere( 1, holdbox.getValue() );

        ScrollPane scrollbar = new ScrollPane();
        scrollbar.setContent(spillerList);
        scrollbar.setPrefSize(600, 200);
        scrollbar.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
        scrollbar.setFitToHeight(true);
        scrollbar.setFitToWidth(true);

        this.setCenter(scrollbar);
        this.setMargin(scrollbar, new Insets(0, 0, 10, 10));
        // SLUT PÅ CENTER
    }

    // METODER    
    public void nulstilGridPane() {
        // Sletter alle elementer, som er på GridPane
        ObservableList<Node> list = spillerList.getChildren();
        for (int i = 6; i < list.size(); i++) {
            list.remove(i);
            i--;
        }
    }
    
    public void gridPaneHoldSpillere( int m, Hold hld ) {
            // Går igennem holdet, der er valgt i holdbox og tilføjer spillere til GridPane
        for( int i = 0; i < hold.getSpillerListe( hld ).size(); i++ ) {
          
             Spiller splr = hold.getSpillerListe( hld ).get(i);
             gridPaneVisuelt(splr, m);
             
             m++; // Rækkenummer som næste spiller skal indsættes på
             
        }
    }
    
    public void gridPaneAlleSpillere( int m, Hold hld ) {
        
    // Nedenstående kører hvis der vælges "Alle Hold" fra ComboBoxen:    
    // Algoritme, der går igennem alle Hold og tilføjer alle Spillere på et givent hold til GridPane
        
        for (int z = 1; z < hold.getList().size(); z++) {
                Hold holdAktuel = hold.getList().get(z);
            for (int x = 0; x < hold.getSpillerListe( holdAktuel ).size(); x++) {
                    Spiller spillerAktuel = hold.getSpillerListe( holdAktuel ).get(x);
                        gridPaneVisuelt( spillerAktuel, m );
                        
                        m++; // Rækkenummer som næste spiller skal indsættes på
            }
        }
    }
    
    public void gridPaneVisuelt( Spiller splr, int m ) {
        
    
     check = new CheckBox();
     rowPane = new StackPane();
        
        
        Text a = new Text( splr.getNavn() );
        Text b = new Text( splr.getHold().getHoldnavn() );
        Text c = new Text();
                c.setText( Integer.toString( splr.getBetaltPris() ) + " kr." );
            
        TextField d = new TextField( splr.getKommentar() );

            spillerList.add(rowPane = new StackPane(), 0, m, 5, 1);
            spillerList.add(a, 0, m);
            spillerList.add(b, 1, m);
            spillerList.add(c, 2, m);
            spillerList.add(d, 4, m);
                    d.setOnKeyTyped(new Tekstfelt(splr, d));
                    
        // Algoritme, der husker at farve rækken og sætte tjek i checkbox afhængig af om spilleren har betalt eller ej
            if (splr.getBetalt()) {
                    rowPane.setStyle("-fx-background-color: #98FB98;");
                    check.setSelected(true);
            } else if ( !splr.getBetalt() && splr.getUdsendRykkerKlikket() ) {
                    rowPane.setStyle("-fx-background-color: #ff0000;");
            } else if (!splr.getBetalt()) {
                    rowPane.setStyle("-fx-background-color: #ffffff;");
                    check.setSelected(false);
            }   
    }
    
    
}


