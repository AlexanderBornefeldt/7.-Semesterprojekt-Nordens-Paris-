/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nordens.paris;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Screen;

/**
 *
 * @author ida705e19
 */
public class TilføjHoldView extends BorderPane {
    
    Hold hold;
    
    // Kalder metode, der tilføjer et hold til systemet
    private class TilføjHoldHandler implements EventHandler<ActionEvent> {
        
        @Override
        public void handle (ActionEvent event) {
            TilføjHold();
            
        Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        KassererView kassererView = new KassererView(hold);
        Scene kView = new Scene(kassererView, bounds.getWidth(), bounds.getHeight()); 
        Kontingentbetalingssystem.getStage().setScene(kView);
        }
    }
    
    // Skifter scene til KassererView
    private class AnnullerHold implements EventHandler<ActionEvent> {
        
        @Override
        public void handle (ActionEvent event) {
            
        Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        KassererView kassererView = new KassererView(hold);
        Scene kView = new Scene(kassererView, bounds.getWidth(), bounds.getHeight()); 
        Kontingentbetalingssystem.getStage().setScene(kView);
        }
    }
    
    TextField holdnavn;
    TextField kontingentpris;
    
    // Konstruktør for TilføjHoldView
    public TilføjHoldView(Hold hld) {
        
        this.hold = hld;
        this.setPadding(new Insets(25, 25, 25, 25));
        
    // Elementer i center af BorderPane.
        GridPane grid = new GridPane();
            Label navn = new Label("Holdnavn:");
                grid.setHgap(10);
                grid.setVgap(50);
            holdnavn = new TextField("Indtast holdnavn...");
                holdnavn.setPrefSize(200, 30);
            Label pris = new Label("Kontingentpris:");
            
            kontingentpris = new TextField("Indtast kontingentpris...");
                kontingentpris.setPrefSize(200, 30);

        grid.add(navn, 0, 0);
        grid.add(holdnavn, 1, 0);
        grid.add(pris, 0, 1);
        grid.add(kontingentpris, 1, 1);
        
        grid.setAlignment(Pos.CENTER);
        
    this.setCenter(grid);
    // Færdig med center

    // Elementer i bunden af BorderPane.
        HBox knapper = new HBox();
            Button annuller = new Button("Annuller");
                annuller.setPrefSize(200, 30);
                    annuller.setOnAction(new AnnullerHold());
            Button gem = new Button("Gem");
                gem.setPrefSize(200, 30);
                    gem.setOnAction(new TilføjHoldHandler());
                    
                    knapper.getChildren().addAll(annuller, gem);
                    knapper.setSpacing(25);
                    knapper.setPadding(new Insets(125, 25, 25, 25));
                    knapper.setAlignment(Pos.CENTER_LEFT);
                
        GridPane logoOgKnap = new GridPane();
            logoOgKnap.add(knapper, 0, 0);
            
                    ColumnConstraints knapperKol = new ColumnConstraints();
                    knapperKol.setPercentWidth(70);
                    logoOgKnap.getColumnConstraints().addAll(knapperKol);
                    
                    ColumnConstraints logoKol = new ColumnConstraints();
                    logoKol.setPercentWidth(30);
                    logoOgKnap.getColumnConstraints().addAll(logoKol);

    this.setBottom(logoOgKnap);
    // Færdig med bunden
    }
    // Metode, der tilføjer et hold
    private void TilføjHold() {
        
        String holdNavn = holdnavn.getText();
        int kontingentPris = Integer.parseInt(kontingentpris.getText());
            Hold hold1 = new Hold(holdNavn, kontingentPris);
                hold.getList().add(hold1); 
    }
    // Metode, informerer brugeren når en handling ikke er tilladt i systemet
    public void ikkeTilladt(String error, String header) {
        
        Alert errorAlert = new Alert(Alert.AlertType.ERROR, error);
            errorAlert.setTitle("Fejlmeddelelse");
            errorAlert.setHeaderText(header);
            errorAlert.showAndWait();
    }
    
}
