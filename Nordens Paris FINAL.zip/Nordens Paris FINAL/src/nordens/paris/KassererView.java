/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nordens.paris;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Screen;

/**
 *
 * @author ida705e19
 */
public class KassererView extends BorderPane {

    Hold hold;
    ComboBox<Hold> holdbox;
    GridPane spillerList;
    CheckBox check;
    StackPane rowPane;
    Text betalingsfrist = new Text();
    Text kontingentPris1;
    VBox kontingentPriser;

    // Eventhandler, udfører kode, når brugeren interagerer med systemet
        // Skifter scene til TilføjSpillerView
    private class tilføjSpillerHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
            TilføjSpillerView tilføjSpillerView = new TilføjSpillerView(hold);
            Scene tsView = new Scene(tilføjSpillerView, bounds.getWidth(), bounds.getHeight());
            Kontingentbetalingssystem.getStage().setScene(tsView);
        }
    }
        // Skifter scene til TilføjHoldView
    private class tilføjHoldHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
            TilføjHoldView tilføjHoldView = new TilføjHoldView(hold);
            Scene thView = new Scene(tilføjHoldView, bounds.getWidth(), bounds.getHeight());
            Kontingentbetalingssystem.getStage().setScene(thView);
        }
    }
        // Skifter scene til RedigerSpillerView
    private class redigerSpiller implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
            RedigerSpillerView redigerSpillerView = new RedigerSpillerView(hold);
            Scene thView = new Scene(redigerSpillerView, bounds.getWidth(), bounds.getHeight());
            Kontingentbetalingssystem.getStage().setScene(thView);
        }
    }
        // Skifter scene til RedigerHoldView
    private class redigerHold implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
            RedigerHoldView redigerHoldView = new RedigerHoldView(hold);
            Scene thView = new Scene(redigerHoldView, bounds.getWidth(), bounds.getHeight());
            Kontingentbetalingssystem.getStage().setScene(thView);
        }
    }
        // Udføres når der vælges et hold i ComboBoxen
    private class VælgHoldHandler implements EventHandler<ActionEvent> {
 
        @Override
        public void handle(ActionEvent event) {
      // Nulstiller alle elementer på GridPanen
            nulstilGridPane();
       
        // Sætter første række i GridPanen
       int m = 1;            
            if( holdbox.getValue() == hold.getList().get(0) ) {
                gridPaneAlleSpillere( m, holdbox.getValue() );
            } else {
                gridPaneHoldSpillere( m, holdbox.getValue() );
            }
        }
    }
        // Skifter scene til BrugerprofilView
    private class TilBrugerProfilView implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
            BrugerprofilView brugerprofilview = new BrugerprofilView(hold);
            Scene thView = new Scene(brugerprofilview, bounds.getWidth(), bounds.getHeight());
            Kontingentbetalingssystem.getStage().setScene(thView);
        }    
    }
        // Markerer en spiller som betalt i systemet
    private class MarkerBetalt implements EventHandler<ActionEvent> {

        CheckBox pressedCheckBox;
        StackPane paneToColor;
        Spiller markeretSpiller;
        Text betaltBeløb;

        public MarkerBetalt(CheckBox checkBut, StackPane rowPane, Spiller g, Text c) {
            this.paneToColor = rowPane;
            this.pressedCheckBox = checkBut;
            this.markeretSpiller = g;
            this.betaltBeløb = c;
        }
            // Sætter attributter og de visuelle elementer i systemet, når en spiller markeres som betalt
        @Override
        public void handle(ActionEvent event) {

            if (!markeretSpiller.getBetalt()) {
                paneToColor.setStyle("-fx-background-color: #98FB98;");
                markeretSpiller.setBetaltPris( markeretSpiller.getHold().getSamletPris() );
                betaltBeløb.setText( Integer.toString( markeretSpiller.getBetaltPris() ) + " kr." );
                markeretSpiller.setBetalt(true);
                
                Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
            KassererView kassererview = new KassererView(hold);
            Scene thView = new Scene(kassererview, bounds.getWidth(), bounds.getHeight());
            Kontingentbetalingssystem.getStage().setScene(thView);
                
            } else if (markeretSpiller.getBetalt()) {
                paneToColor.setStyle("-fx-background-color: #ffffff;");
                markeretSpiller.setBetaltPris( markeretSpiller.getHold().getSamletPris() );
                betaltBeløb.setText( Integer.toString( markeretSpiller.getBetaltPris() ) + " kr." );
                markeretSpiller.setBetalt(false);
                
                Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
            KassererView kassererview = new KassererView(hold);
            Scene thView = new Scene(kassererview, bounds.getWidth(), bounds.getHeight());
            Kontingentbetalingssystem.getStage().setScene(thView);
            } 
        }
    }
    
        // Tilføjer en kommentar til en spiller
    private class Tekstfelt implements EventHandler<KeyEvent> {
        
        TextField txtf;
        Spiller markeretSpiller;
        
        public Tekstfelt(Spiller g, TextField t) {
            this.markeretSpiller = g;
            this.txtf = t;
        }
        @Override
        public void handle(KeyEvent event) {  
            markeretSpiller.setKommentar( txtf.getText() );   
        }
    }
        // Starter en betalingsperiode. Læg mærke til, at der er implementeret en sikkerhed i form af en bekræft-metode, 
        // som beder brugeren bekræfte hans valg om at starte en betalingsperiode
    private class StartBetalingsperiode implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            
            if ( bekræft("Er du sikker på, at du vil starte en ny betalingsperiode?", "Start Betalingsperiode") ) {
                hold.startBP(true);
                    hold.setBetalingsfrist( LocalDate.now().plusMonths(1) );
                        betalingsfrist.setText( "Frist for betaling: " + hold.getBetalingsfrist().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG)) );
                        betalingsfrist.setFill(Color.BLACK);
            }
        }
    }
    
        // Udsender rykker
    private class UdsendRykker implements EventHandler<ActionEvent> {
            
        @Override
        public void handle(ActionEvent event) {
            
            if( hold.getStartBP() ) {
                if ( bekræft("Er du sikker på, at du vil pålægge rykkere?", "Pålæg Rykkere") ) {
            
                    for( int a = 1; a < hold.getList().size(); a++ ) {
                        Hold hld = hold.getList().get(a);
                            hld.tilføjRykker();
                        kontingentPris1.setText( hold.getList().get(a).getHoldnavn()
                            + " : " + hold.getList().get(a).getSamletPris() + " kr.");
                
                            for( int b = 0; b < hold.getSpillerListe(hld).size(); b++ ) {
                                Spiller splr = hold.getSpillerListe(hld).get(b);
                                    splr.UdsendRykkerKlikket(true);
                            }
                    }   
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
            KassererView kassererview = new KassererView(hold);
            Scene thView = new Scene(kassererview, bounds.getWidth(), bounds.getHeight());
            Kontingentbetalingssystem.getStage().setScene(thView);
                }
            } else if( !hold.getStartBP() ) {
                ikkeTilladt("Start betalingsperiode før du kan nulstille betalinger", "Betalingsperiode ikke aktiv");
            }
        }
    }

        // Nulstiller alle betalinger
    private class NulstilBetalinger implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            
            if( hold.getStartBP() ) {    
                if( bekræft("Er du sikker på, at du vil nulstille betalinger?", "Nulstil Betalinger") ) {
 
                    for (int z = 1; z < hold.getList().size(); z++) {
                        Hold holdAktuel = hold.getList().get(z);
                            // Nulstil rykkergebyr for alle hold
                            holdAktuel.setRykkergebyr(0);
                        for (int x = 0; x < hold.getSpillerListe( holdAktuel ).size(); x++) {
                            Spiller spillerAktuel = hold.getSpillerListe( holdAktuel ).get(x);
                                // Nulstil betaling for alle spillere
                                spillerAktuel.setBetalt(false);
                                spillerAktuel.UdsendRykkerKlikket(false);
                        }
                    }
                    hold.startBP(false);
            Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
            KassererView kassererview = new KassererView(hold);
            Scene thView = new Scene(kassererview, bounds.getWidth(), bounds.getHeight());
            Kontingentbetalingssystem.getStage().setScene(thView);
                }
            } else if( !hold.getStartBP() ) {
                ikkeTilladt("Start betalingsperiode før du kan nulstille betalinger", "Betalingsperiode ikke aktiv");
            }
        }    
    }

    // Konstruktør for KassererView
    public KassererView(Hold hld) {

        this.hold = hld;
        this.setPadding(new Insets(25, 25, 25, 25));

        // Elementer på venstre side af BorderPane, som KassererView extender
        VBox venstre = new VBox();

        kontingentPriser = new VBox();

        for (int a = 1; a < hold.getList().size(); a++) {
            kontingentPris1 = new Text(hold.getList().get(a).getHoldnavn()
                    + " : " + hold.getList().get(a).getSamletPris() + " kr.");
            kontingentPris1.setFont(Font.font("Verdana", 16));
            kontingentPriser.getChildren().add(kontingentPris1);
        }

        holdbox = new ComboBox<>(FXCollections.observableArrayList(hold.getList()));
        holdbox.getSelectionModel().selectFirst();
        holdbox.setPrefSize(200, 30);
            holdbox.setOnAction(new VælgHoldHandler());
            
        Button startBP = new Button("Start Betalingsperiode");
        startBP.setPrefSize(200, 30);
        startBP.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
            startBP.setOnAction(new StartBetalingsperiode());
            
        if( hold.getStartBP() ) {
            betalingsfrist.setText( "Frist for betaling: "  + hold.getBetalingsfrist().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG)) );
            betalingsfrist.setFill(Color.BLACK);
        } else if( !hold.getStartBP() ) {
            betalingsfrist.setText( "Betalingsperiode ikke aktiv");
            betalingsfrist.setFill(Color.RED);
        }

        Button udsendRykker = new Button("Pålæg Rykker");
        udsendRykker.setPrefSize(200, 30);
        udsendRykker.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
            udsendRykker.setOnAction(new UdsendRykker());

        Button nulstilBetalinger = new Button("Nulstil Betalinger");
        nulstilBetalinger.setPrefSize(200, 30);
        nulstilBetalinger.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
            nulstilBetalinger.setOnAction(new NulstilBetalinger());

        venstre.getChildren().addAll( holdbox, startBP, betalingsfrist, udsendRykker, nulstilBetalinger, kontingentPriser );
        venstre.setSpacing(25);
        venstre.setPadding(new Insets(50, 25, 0, 0));

        this.setLeft(venstre);
        // Færdig med venstre side

        // Elementer i toppen af BorderPane
        GridPane top = new GridPane();
        top.setHgap(100);
        top.setVgap(0);
        top.setAlignment(Pos.CENTER);

        Button tilføjSpiller = new Button("Tilføj Spiller");
            tilføjSpiller.setPrefSize(200, 30);
            tilføjSpiller.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
                tilføjSpiller.setOnAction(new tilføjSpillerHandler());

        Button redigerSpiller = new Button("Rediger Spiller");
            redigerSpiller.setPrefSize(200, 30);
            redigerSpiller.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
                redigerSpiller.setOnAction(new redigerSpiller());

        Button tilføjHold = new Button("Tilføj Hold");
            tilføjHold.setPrefSize(200, 30);
            tilføjHold.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
                tilføjHold.setOnAction(new tilføjHoldHandler());

        Button redigerHold = new Button("Rediger Hold");
            redigerHold.setPrefSize(200, 30);
            redigerHold.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
                redigerHold.setOnAction(new redigerHold());
                
        Button tilBrugerProfil = new Button("Skift Brugerprofil");
            tilBrugerProfil.setPrefSize(200, 30);
            tilBrugerProfil.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
                tilBrugerProfil.setOnAction(new TilBrugerProfilView());          

        HBox spillerKnapperTop = new HBox();
            spillerKnapperTop.getChildren().addAll(tilføjSpiller, redigerSpiller);
            spillerKnapperTop.setSpacing(20);
            spillerKnapperTop.setPadding(new Insets(0, 0, 25, 220));

        HBox holdKnapperTop = new HBox();
            holdKnapperTop.getChildren().addAll(tilføjHold, redigerHold);
            holdKnapperTop.setSpacing(20);
            holdKnapperTop.setPadding(new Insets(0, 150, 25, 0));
         
        HBox tilBPtop = new HBox();
            tilBPtop.getChildren().add(tilBrugerProfil);
            tilBPtop.setPadding(new Insets(0, 0, 25, 0));
            tilBPtop.setAlignment(Pos.CENTER_RIGHT);
            

        top.add(spillerKnapperTop, 0, 0);
        top.add(holdKnapperTop, 1, 0);
        top.add(tilBPtop, 2, 0);
        this.setTop(top);
        // Færdig med toppen

        // Elementer i center af BorderPane. Nærmere specifikt relateret til den GridPane, der viser spillerne i systemet.
        spillerList = new GridPane();
            spillerList.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
            spillerList.setPadding(new Insets(25, 0, 0, 25));
            spillerList.setStyle("-fx-border-width: 1; -fx-border-color: black;");

        Text navn = new Text("Navn");
            navn.setFont(Font.font("Verdana", FontWeight.BOLD, 16));
        Text holdNavn = new Text("Hold");
            holdNavn.setFont(Font.font("Verdana", FontWeight.BOLD, 16));
        Text betaltBeløb = new Text("Beløb");
            betaltBeløb.setFont(Font.font("Verdana", FontWeight.BOLD, 16));
        Text betaltEllerEj = new Text("Betalt");
            betaltEllerEj.setFont(Font.font("Verdana", FontWeight.BOLD, 16));
        Text kommentar = new Text("Kommentar");
            kommentar.setFont(Font.font("Verdana", FontWeight.BOLD, 16));
            
        ColumnConstraints spillerNavnKol = new ColumnConstraints();
            spillerNavnKol.setPercentWidth(30);
                spillerList.getColumnConstraints().addAll(spillerNavnKol);

        ColumnConstraints holdNavnKol = new ColumnConstraints();
            holdNavnKol.setPercentWidth(15);
                spillerList.getColumnConstraints().addAll(holdNavnKol);

        ColumnConstraints betaltBeløbKol = new ColumnConstraints();
            betaltBeløbKol.setPercentWidth(10);
                spillerList.getColumnConstraints().addAll(betaltBeløbKol, betaltBeløbKol);

        ColumnConstraints kommentarKol = new ColumnConstraints();
            kommentarKol.setPercentWidth(44);
                spillerList.getColumnConstraints().addAll(kommentarKol);

        ColumnConstraints scrollbarKol = new ColumnConstraints();
            scrollbarKol.setPercentWidth(1);
                spillerList.getColumnConstraints().add(scrollbarKol);

        spillerList.add(navn, 0, 0);
        spillerList.add(holdNavn, 1, 0);
        spillerList.add(betaltBeløb, 2, 0);
        spillerList.add(betaltEllerEj, 3, 0);
        spillerList.add(kommentar, 4, 0);

        gridPaneAlleSpillere( 1, holdbox.getValue() );
        
        ScrollPane scrollbar = new ScrollPane();
        scrollbar.setContent(spillerList);
        scrollbar.setPrefSize(600, 200);
        scrollbar.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
        scrollbar.setFitToHeight(true);
        scrollbar.setFitToWidth(true);

        this.setCenter(scrollbar);
        this.setMargin(scrollbar, new Insets(0, 0, 10, 10));
        // Færdig med center
    }

    // Metoder
    
        // Sletter alle elementer, som er på GridPane
    public void nulstilGridPane() {
        ObservableList<Node> list = spillerList.getChildren();
        for (int i = 6; i < list.size(); i++) {
            list.remove(i);
            i--;
        }
    }
        // Går igennem holdet, der er valgt i holdbox og tilføjer spillere til GridPane
    public void gridPaneHoldSpillere( int m, Hold hld ) {
        for( int i = 0; i < hold.getSpillerListe( hld ).size(); i++ ) {
          
             Spiller splr = hold.getSpillerListe( hld ).get(i);
             gridPaneVisuelt(splr, m);
             
             m++; // Rækkenummer som næste spiller skal indsættes på
             
        }
    }
    
    // Nedenstående kører hvis der vælges "Alle Hold" fra ComboBoxen:    
    // Metoder, der går igennem alle Hold og tilføjer alle Spillere på et givent hold til GridPane
    public void gridPaneAlleSpillere( int m, Hold hld ) {

        for (int z = 1; z < hold.getList().size(); z++) {
                Hold holdAktuel = hold.getList().get(z);
                 sorter( hold.getSpillerListe(holdAktuel) );
                
            for (int x = 0; x < hold.getSpillerListe( holdAktuel ).size(); x++) {
                    Spiller spillerAktuel = hold.getSpillerListe( holdAktuel ).get(x);
                    sorter( hold.getSpillerListe(holdAktuel) );
                        gridPaneVisuelt( spillerAktuel, m );
                        m++; // Rækkenummer som næste spiller skal indsættes på
            }
        }
    }
    
    // Metoder, der tilføjer alt det visuelle til en spiller i GridPanen. Læg mærke til, at metoden kører når ovenstående metode kaldes.
    public void gridPaneVisuelt( Spiller splr, int m ) {
        
     check = new CheckBox();
     rowPane = new StackPane();
        
        Text a = new Text( splr.getNavn() );
        Text b = new Text( splr.getHold().getHoldnavn() );
        Text c = new Text();
                c.setText( Integer.toString( splr.getBetaltPris() ) + " kr." );
            
        TextField d = new TextField( splr.getKommentar() );

            spillerList.add(rowPane = new StackPane(), 0, m, 5, 1);
            spillerList.add(a, 0, m);
            spillerList.add(b, 1, m);
            spillerList.add(c, 2, m);
            spillerList.add(check = new CheckBox(), 3, m);
                    check.setOnAction(new MarkerBetalt(check, rowPane, splr, c));
            spillerList.add(d, 4, m);
                    d.setOnKeyTyped(new Tekstfelt(splr, d));
                    
        // Algoritme, der husker at farve rækken og sætte tjek i checkbox afhængig af om spilleren har betalt eller ej
            if (splr.getBetalt()) {
                    rowPane.setStyle("-fx-background-color: #98FB98;");
                    check.setSelected(true);
            } else if ( !splr.getBetalt() && splr.getUdsendRykkerKlikket() ) {
                    rowPane.setStyle("-fx-background-color: #ff0000;");
            } else if (!splr.getBetalt()) {
                    rowPane.setStyle("-fx-background-color: #ffffff;");
                    check.setSelected(false);
            }   
    }
    
    // Metode, der beder brugeren bekræfte hans valg. Sikkerhed i tifælde af, at brugeren klikker forkert i systemet.
    public boolean bekræft(String bekræftelse, String title) {
        
        Alert alert = new Alert(AlertType.CONFIRMATION, bekræftelse);
            alert.setTitle(title);
            alert.setHeaderText("Vær venlig at bekræfte:");
        ButtonType ja = new ButtonType("Ja", ButtonBar.ButtonData.OK_DONE);
        ButtonType nej = new ButtonType("Nej", ButtonBar.ButtonData.CANCEL_CLOSE);
            alert.getButtonTypes().set(0, ja);
            alert.getButtonTypes().set(1, nej);
        Optional<ButtonType> result = alert.showAndWait();
        
        return result.isPresent() && result.get() == ja;
    }
    
    // Metode, der advarer brugeren når noget ikke er tilladt. For eksempel hvis denne er i gang med at slette et hold, som der stadig er spillere tilknyttet. 
    // I advarslen vil der også stå beskrevet hvad det er, som ikke er tilladt. På den måde vil brugeren vide hvad han skal ændre, før at den igangværende handling bliver tilladt.
    public void ikkeTilladt(String error, String header) {
        
        Alert errorAlert = new Alert(AlertType.ERROR, error);
            errorAlert.setTitle("Fejlmeddelelse");
            errorAlert.setHeaderText(header);
            errorAlert.showAndWait();
    }
    
    // Metode, sorterer spillere i en spillerliste, i betalte og ikke-betalte.
    // Vi implementerer sorteringsalgoritme ved at importere en Collections klasse og overrider en compare metode.
    // Dette gør vi for at holde vores kode optimeret.
    public void sorter( ArrayList<Spiller> splr) {
        
        Collections.sort(splr, new Comparator<Spiller>() {
            @Override
            public int compare(Spiller o1, Spiller o2) {
                
                boolean b1 = o1.getBetalt();
                boolean b2 = o2.getBetalt();
                
                return (b1 != b2) ? (b2) ? -1 : 1 : 0;
               
            }
        } );
     
        
    }
    
}


